package GUI;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class spring21_5 {
    public spring21_5() {
        JFrame frame = new JFrame("My Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 150);
        frame.setLayout(new FlowLayout());

        JButton upButton = new JButton();
        upButton.setText("Up");

        JLabel middleLabel = new JLabel();
        middleLabel.setText("A JLabel Object can display either text," +
                "an image, or both");

        frame.add(upButton);
        frame.add(middleLabel);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new spring21_5();
    }
}