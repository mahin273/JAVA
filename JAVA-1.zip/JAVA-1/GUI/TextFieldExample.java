package GUI;
import javax.swing.*;
import java.awt.event.*;


public class TextFieldExample implements ActionListener {
    JTextField tf1, tf2, td3;
    JButton b1, b2;

    TextFieldExample() {
        Jframe f = new JFrame();
        tf1 = new JTextField();
        tf1.setBounds(50, 50, 150, 20);
    }
    // https://www.javatpoint.com/java-jtextfield
}
