package GUI;

import java.awt.event.*;

import javax.swing.*;

public class LableExample extends JFrame implements ActionListener {
  
    JTextField tf;
    JLabel l;
    JButton b;

    public LableExample() {
        tf = new JTextField();
        tf.setBounds(50, 50, 150, 20);
        l = new JLabel();
        l.setBounds(50, 100, 150, 20);
        b = new JButton("Find  IP");
        b.setBounds(50, 150, 80, 30);
        b.addActionListener(this);
        add(tf);
        add(l);
        add(b);
        setSize(500, 500);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
    try {
        String host = tf.getText();
        String ip = java.net.InetAddress.getByName(host).getHostAddress();
        l.setText("IP of " + host + " is: " + ip);

    }catch(Exception ex) {
        System.out.println(ex);
    }
    }
    public static void main(String[] args) {
        new LableExample();
    }
}
