package GUI;
import javax.swing.*;
import java.awt.*;
public class fall19_3a extends JFrame {
    public fall19_3a() {
        setTitle("My GUI Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);

        // Create the buttons
        JButton button1 = new JButton("Button 1");
        JButton button2 = new JButton("Button 2");
        JButton button3 = new JButton("Button 3");
        JButton button4 = new JButton("Button 4");
        JButton button5 = new JButton("Button 5");

        // Create the panels
        JPanel headerPanel = new JPanel();
        JPanel linksPanel = new JPanel();
        JPanel contentsPanel = new JPanel(new BorderLayout());
        JPanel adsPanel = new JPanel();
        JPanel footerPanel = new JPanel();

        // Add the buttons to the panels
        headerPanel.add(new JLabel("Header"));
        linksPanel.add(button1);
        linksPanel.add(button2);
        linksPanel.add(button3);
        contentsPanel.add(new JLabel("Contents"), BorderLayout.CENTER);
        adsPanel.add(new JLabel("Ads"));
        footerPanel.add(new JLabel("Footer"));

        // Add the panels to the frame
        add(headerPanel, BorderLayout.NORTH);
        add(linksPanel, BorderLayout.WEST);
        add(contentsPanel, BorderLayout.CENTER);
        add(adsPanel, BorderLayout.EAST);
        add(footerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        new fall19_3a();
    }
}