package GUI;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class spring20_3b implements ActionListener {
    private JFrame frame;
    private JTextField footField;
    private JTextField inchField;
    private JButton convertButton;
    private JButton convertToFootButton;

    public spring20_3b() {
        frame = new JFrame("Foot to Inch Converter");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 150);
        frame.setLayout(new GridLayout(3, 1));

        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel footLabel = new JLabel("Foot:");
        footField = new JTextField(10);
        panel1.add(footLabel);
        panel1.add(footField);

        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        convertButton = new JButton("Convert to Inch");
        convertToFootButton = new JButton("Convert to Foot");
        panel2.add(convertButton);
        panel2.add(convertToFootButton);

        JPanel panel3 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel inchLabel = new JLabel("Inch:");
        inchField = new JTextField(10);
        panel3.add(inchLabel);
        panel3.add(inchField);

        convertButton.addActionListener(this);
        convertToFootButton.addActionListener(this);

        frame.add(panel1);
        frame.add(panel2);
        frame.add(panel3);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == convertButton) {
            double foot = Double.parseDouble(footField.getText());
            double inch = foot * 12;
            inchField.setText(String.valueOf(inch));
        } else if (e.getSource() == convertToFootButton) {
            double inch = Double.parseDouble(inchField.getText());
            double foot = inch / 12;
            footField.setText(String.valueOf(foot));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new spring20_3b();
            }
        });
    }
}