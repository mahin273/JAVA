package GUI;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class summer21_2 {
    public static void main(String[] args) {
        JFrame fr = new JFrame("RUN!");
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fr.setSize(250, 100);
        fr.setLayout(new FlowLayout());
      
        JLabel label = new JLabel();
        JButton button = new JButton("Click!");

        button.addActionListener(new ActionListener() {
            int count = 3; // initial count

            @Override
            public void actionPerformed(ActionEvent e) {
                if (count > 0) {
                    label.setText(count + "...");
                    count--;
                } else if (count == 0) {
                    label.setText("GO!");
                    count--;
                }
            }
        });

        fr.add(label);
        fr.add(button);
        fr.setVisible(true);
    }
}