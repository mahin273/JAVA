package GUI;

import javax.swing.*;
import java.awt.event.*;

class fall19_3b implements ActionListener {
    JButton flip, rotate;
    JTextField text;

    fall19_3b() {
        JFrame frame = new JFrame("fall19_3b");
        JPanel panel = new JPanel();
        frame.setContentPane(panel);
        frame.setSize(280, 150);
        frame.setLocation(300, 200);
        text = new JTextField(10);
        text.setText(">");
        flip = new JButton("Flip");
        rotate = new JButton("Rotate");
        panel.add(flip);
        panel.add(rotate);
        panel.add(text);

        // 1. Add your code here
        flip.addActionListener(this);
        rotate.addActionListener(this);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == flip) {
            text.setText(flipMe(text.getText()));
        } else if (e.getSource() == rotate) {
            text.setText(rotateMe(text.getText()));
        }
    }

    static String flipMe(String text) {
        if (text.equals(">")) return "<";
        if (text.equals("<")) return ">";
        return text;
    }

    static String rotateMe(String text) {
        if (text.equals(">")) return "v";
        if (text.equals("v")) return "<";
        if (text.equals("<")) return "^";
        if (text.equals("^")) return ">";
        return text;
    }

    public static void main(String[] args) {
        new fall19_3b();
    }
}