package GUI;

import java.awt.event.*;
import javax.swing.*;



public class ButtonExample {
    public static void main(String[] args) {
        JFrame f = new JFrame("Button Example");
        final JTextField tf = new JTextField();
        tf.setBounds(150, 130, 150, 20);

        JButton b = new JButton("Click Here");
        b.setBounds(150, 150, 95, 30);
        b.setBackground(java.awt.Color.red);
        b.setForeground(java.awt.Color.white);
        b.setBorder(BorderFactory.createBevelBorder(3));
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e ){
                tf.setText("Welcome to GUI");
            }
        });
        f.add(b);
        f.add(tf);
        f.setSize(400, 400);
        f.setLayout(null);
        f.setVisible(true);
    }
    
}
