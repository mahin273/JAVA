package GUI;

import java.awt.GridLayout;
import java.awt.event.*;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class fall20_3a {
    public static void main(String[] args) {
        JFrame f = new JFrame("Oceans App");
        f.setSize(300, 150);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(new GridLayout(3, 1));

        String[] oceans = { "Arctic", "North Atlantic", "South Atlantic", "Indian",
                "North Pacific", "South Pacific", "Indian", "Antarctic" };
        JTextField indexField = new JTextField(20);
        JTextField oceanNameField = new JTextField(20);
        JButton showButton = new JButton("Show");

        showButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int index = Integer.parseInt(indexField.getText());
                if (index >= 0 && index < oceans.length) {
                    oceanNameField.setText(oceans[index]);
                }
            }
        });

        JPanel inputPanel = new JPanel();
        inputPanel.add(indexField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(showButton);

        JPanel outputPanel = new JPanel();
        outputPanel.add(oceanNameField);

        f.add(inputPanel);
        f.add(outputPanel);
        f.add(buttonPanel);

        f.setVisible(true);
    }
}