package GUI;

import javax.swing.*;
import java.awt.event.*;


public class summer20_3a extends JFrame implements ActionListener {
    private JTextField euro;
    private JTextField usd;

    summer20_3a(String n) {
        setTitle(n);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);

        JPanel p = new JPanel();
        JLabel l1 = new JLabel("Euro");
        p.add(l1);
        euro = new JTextField("0.0", 10);
        p.add(euro);
        JLabel l2 = new JLabel("USD");
        p.add(l2);
        usd = new JTextField("0.0", 10);
        p.add(usd);
        JButton b = new JButton("Get USD value");
        b.addActionListener(this);
        p.add(b);

        setContentPane(p);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Get USD value")) {
            double euroValue = Double.parseDouble(euro.getText());
            double usdValue = euroValue * 1.16;
            usd.setText(String.valueOf(usdValue));
        }
    }

    public static void main(String[] args) {
        new summer20_3a("Currency Converter");
    }
}