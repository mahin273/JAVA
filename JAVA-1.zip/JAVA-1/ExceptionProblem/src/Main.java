import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        while (true) {
            try{
            Scanner input = new Scanner(System.in);
        System.out.println("Please Enter a number 1 : ");
        int num1 = input.nextInt();
        System.out.println("Enter number 2: ");
        int num2 = input.nextInt();
        int result = num1 / num2;
        System.out.println("Result: "+num1+"/"+num2 +"="+ result);

}catch(Exception e){
    System.out.println("Exception: " + e);
    System.out.println("You must have to input integer.Please try again");
}
        } 

    }
}
