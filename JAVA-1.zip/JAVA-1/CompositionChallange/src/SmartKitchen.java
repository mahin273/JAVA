public class SmartKitchen {
    private CoffeeMaker brewMaster;
    private Refrigerator iceBox;
    private DishWasher dishWasher;
    public SmartKitchen(){
        brewMaster = new CoffeeMaker();
        iceBox = new Refrigerator();
        dishWasher = new DishWasher();
    }

    public CoffeeMaker getBrewMaster() {
        return brewMaster;
    }

    public Refrigerator getIceBox() {
        return iceBox;
    }

    public DishWasher getDishWasher() {
        return dishWasher;
    }
    public void setKitchenState(boolean coffeeFlag, boolean fridgeFlag, 
    boolean dishWasherFlag){
        brewMaster.setHashWorkToDo(coffeeFlag);
        iceBox.setHashWorkToDo(fridgeFlag);
        dishWasher.setHashWorkToDo(dishWasherFlag);
    }
    public void doKitchenWork(){
        brewMaster.brewCoffee();
        iceBox.orderFood();
        dishWasher.doDishes();
    }
}


class CoffeeMaker{
      private boolean hashWorkToDo;

    public void setHashWorkToDo(boolean hashWorkToDo) {
        this.hashWorkToDo = hashWorkToDo;
    }
    public void brewCoffee(){
        if (hashWorkToDo){
            System.out.println("Brewing Coffee");
            hashWorkToDo = false;
        }
    }
}

class Refrigerator{
    private boolean hashWorkToDo;

    public void setHashWorkToDo(boolean hashWorkToDo) {
        this.hashWorkToDo = hashWorkToDo;
    }
    public void orderFood(){
        if (hashWorkToDo){
            System.out.println("Ordering Food");
            hashWorkToDo = false;
        }
    }
}
class DishWasher {
    private boolean hashWorkToDo;

    public void setHashWorkToDo(boolean hashWorkToDo) {
        this.hashWorkToDo = hashWorkToDo;
    }
    public void doDishes(){
        if (hashWorkToDo){
            System.out.println("Washing Dishes");
            hashWorkToDo = false;
        }
    }
}
