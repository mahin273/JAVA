
public class Ternary {
    public static void main(String[] args) {
        int x = 4;
        String result = ((x % 2 == 0) ? "Even" : "ODD");
        System.out.println(result);
    }
    
}
