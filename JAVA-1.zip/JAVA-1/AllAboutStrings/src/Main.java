public class Main {
    public static void main(String[] args) {
        printInformation("Hello World");
        printInformation("");
        printInformation("\t   \n");
        String helloWorld = "hello world";
        System.out.printf("Index of 'r' = %d%n", helloWorld.indexOf('r'));
        System.out.printf("Index of 'World' = %d%n", helloWorld.indexOf("world"));
        System.out.printf("Index of 'l' = %d%n", helloWorld.indexOf('l'));
        System.out.printf("Last index of 'l' before index 3 = %d%n", helloWorld.lastIndexOf('l', 3));
        System.out.printf("Index of 'l' = %d%n", helloWorld.indexOf('l'));
        System.out.printf("Last index of 'l' before index 8 = %d%n", helloWorld.lastIndexOf('l', 8));
        String helloWorldLower = helloWorld.toLowerCase();
        if (helloWorld.equals(helloWorldLower)) {
            System.out.println("Values Match Exactly");
        }
        if (helloWorld.equalsIgnoreCase(helloWorldLower)) {
            System.out.println("Values match ignoring case");
        }
        if (helloWorld.toLowerCase().startsWith("hello")) {
            System.out.println("String starts with 'Hello'");
        }
        if (helloWorld.toLowerCase().endsWith("world")) {
            System.out.println("String ends with 'world'");
        }
        if (helloWorld.toLowerCase().contains("world")) {
            System.out.println("String contains 'world'");
        }
        if (helloWorld.toLowerCase().equals("hello world")) {
            System.out.println("Values match exactly");
        }
    }
    public static void printInformation(String string) {
        int length = string.length();
        System.out.printf("Length = %d%n", length);
        if (string.isEmpty()) {
            System.out.println("String is empty");
            return;
        }
        if (string.isBlank()) {
            System.out.println("String is blank");
        }
        System.out.printf("First character = %c%n", string.charAt(0));
        System.out.printf("Last character = %c%n", string.charAt(length - 1));
    }
}