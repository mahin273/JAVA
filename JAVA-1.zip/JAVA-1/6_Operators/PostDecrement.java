public class PostDecrement {
    public static void main(String[] args) {
        int a = 10;
        int b = a--;
        System.out.println(a);
        System.out.println(b);
    }
}
