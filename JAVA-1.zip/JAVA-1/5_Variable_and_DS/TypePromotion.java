

public class TypePromotion {
    public static void main(String args[]) {
        char a = 'a';
        char b = 'b';
        System.out.println(b - a);
    }
}
