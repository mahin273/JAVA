public class TypePromotion2 {
    public static void main(String[] args) {
        byte b = 5;
        // byte a = b * 2;
        byte a = (byte) (b * 2);
        System.out.println(a);
    }
}
