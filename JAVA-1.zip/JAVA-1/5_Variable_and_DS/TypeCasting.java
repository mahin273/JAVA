import java.util.Scanner;

public class TypeCasting {
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        float a = sc.nextFloat();
        int b = (int) a;
        System.out.println(b);
        sc.close();

    }
}