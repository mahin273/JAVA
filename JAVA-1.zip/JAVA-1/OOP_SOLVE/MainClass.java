package OOP_SOLVE;

public class MainClass {
    public static void main(String[] args) {
        Child n = new Child(4);
        System.out.println(n.i);
    }
}
class Parent {
    int i = 10;
    public Parent(int j){
        System.out.println(i);
        j=j*2;
        this.i = j*10;
    }
}
class Child extends Parent{
    public Child(int j){
        super(j);
        System.out.println(i);

        this.i = j*20;
    }
}

