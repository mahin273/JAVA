public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            String name;
            switch (i) {
                case 1:
                    name = "Marry";
                    break;
                case 2:
                    name = "Carol";
                    break;
                case 3:
                    name = "Daryl";
                    break;
                case 4:
                    name = "Rick";
                    break;
                case 5:
                    name = "Jesus";
                    break;
                default:
                    name = "Anonymous";
            }
            LPAStudent s = new LPAStudent("S92300" + i, name,  "28/12/2002", "Java Masterclass");
            System.out.println(s);
        }
        Student pojoStudent = new Student("s9230", "Mahin",
                "28/112/2002", "Java Masterclass");
        LPAStudent recordStudent = new LPAStudent("5000","Rick",
                "23/12/1998","Java Masterclass");
        System.out.println(pojoStudent);
        System.out.println(recordStudent);
        pojoStudent.setClassList(pojoStudent.getClassList()+ ", Java OCP Exam 829");
//        recordStudent.setClassList(pojoStudent.getClassList()+ ", Java OCP Exam 829");

        System.out.println(pojoStudent.getName()+" is taking "+
                pojoStudent.getClassList());
        System.out.println(recordStudent.name()+" is taking "+
                recordStudent.classList());
    }
}