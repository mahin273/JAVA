import java.util.*;
public class Main{
    public static void main(String[] args) {
       // Main objectName = new Main();
        
        ArrayList<Integer> list = new ArrayList<Integer>();
        ArrayList<String> list2 = new ArrayList<String>();
        ArrayList<Boolean>list3 = new ArrayList<>();

        //Add Operation
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(1, 9);
 
        System.out.println(list.size());
        //print arraylist
        for(int i = 0;i<list.size();i++){
            System.out.print(list.get(i)+" ");

        }
        System.out.println();
        //print arraylist in reverse order
        for(int i = list.size()-1;i>= 0;i--){
            System.out.print(list.get(i)+" ");
        }
        System.out.println();
         
        System.out.println(list);

        //Get operation
        int element = list.get(3 );
        System.out.println(element);

        //Remove Operation
        list.remove(3);
        System.out.println(list);

        //Set Element at Index
        list.set(2, 11);
        System.out.println(list);

        //Contain elements-->chech specific element exit or not
        System.out.println(list.contains(1));
        System.out.println(list.contains(12));
    }
}

