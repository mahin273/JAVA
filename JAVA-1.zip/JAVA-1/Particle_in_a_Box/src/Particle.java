public class Particle {
    private double charge;
    public Particle(double charge){
        this.charge = charge;

    }
    public double getCharge(){
        return charge;
    }
}
