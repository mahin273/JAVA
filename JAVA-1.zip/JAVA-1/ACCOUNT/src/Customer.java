public class Customer {
    private String name;
    private int creditLimit;
    private String address;

    public Customer(String name, int creditLimit, String address) {
        this.name = name;
        this.creditLimit = creditLimit;
        this.address = address;
    }
public  Customer(){
this("Nobody","nobody@nowhere.com");
}

    public Customer(String name, String address) {
      this(name,1000,address);

    }

    public String getName() {
        return name;
    }

    public int getCreditLimit() {
        return creditLimit;
    }

    public String getAddress() {
        return address;
    }
}
