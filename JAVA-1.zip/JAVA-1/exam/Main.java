class Area {
 private int length;
 private int width;
 public Area(int length, int width) {
 this.length = length;
 this.width = width;
 }
 public int returnArea() {
 return length * width;
 }
 {
 System.out.println("The area A of a rectangle is given by the formula, A = lw, where l is the length and w is the width.");
 }
}
public class Main {
 public static void main(String[] args) {
 Area rectangle = new Area(5, 7);
 int area = rectangle.returnArea();
 System.out.println("The area of the rectangle is: " + area);
 }
}