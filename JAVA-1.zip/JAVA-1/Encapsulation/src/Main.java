public class Main {
    public static void main(String[] args){
    //    Player player = new Player();
    //    player.fullName="Tim";
    //    player.health = 20;
    //    player.weapon ="Sword";

    //    int damage = 10;
    //    player.loseHeath(damage);
    //    System.out.println("Damaged health = "+damage);
    //    System.out.println("Remaining Health = "+player.healthReamining());
    //    player.health = 200;
    //    player.loseHeath(11);
    //    System.out.println("Remaining health = "+ player.healthReamining());
EnhancedPlayer mahin = new EnhancedPlayer("Mahin",200,"Sword");
System.out.println("Initial health is "+ mahin.healthReamining());
    }
}
