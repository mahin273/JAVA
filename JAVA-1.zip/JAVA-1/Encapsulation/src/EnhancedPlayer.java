public class EnhancedPlayer {
    private String fullName;
    private int healthParcentage;
    private String weapone;

    
    public EnhancedPlayer(String name) {
       this(name,100,"Sword");
    }


    public EnhancedPlayer(String name, int helath,
     String weapone) {
        this.fullName = name;
        if(helath<=0){
            this.healthParcentage = 1;
        }else if(helath>100){
            this.healthParcentage = 100;
        }else{
            this.healthParcentage = helath;
        }
        this.weapone = weapone;
    }

    public void loseHeath(int damage){
        healthParcentage = healthParcentage - damage;
        if(healthParcentage <=0){
           System.out.println("Player knocked out of the game"); 
        }
    }
    public int healthReamining(){
        return healthParcentage;
    }
    public void restoreHealth(int extraHealth){
healthParcentage = healthParcentage +extraHealth;
if(healthParcentage >100){
    System.out.println("Player restored to 100%");
    healthParcentage = 100;
}
    }
    
}
