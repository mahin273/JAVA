public class Main {
    public static void main(String[] args) {
        System.out.println("My name is");
        try {
            int x = 10;
            int y = 0;
            int result = x / y;
            System.out.println("Result = " + result);
        } catch (ArrayIndexOutOfBoundsException e1) {
            System.out.println("Exception " + e1);
        } catch (ArithmeticException e) {
            System.out.println("Exception: " + e);
        }
        try {
             int[] a = new int[4];
            a[4] = 10;
        } catch (ArrayIndexOutOfBoundsException e3) {
            System.out.println("Exception :"+e3);
        }
finally{
       System.out.println("Mahin Khan");
}
        System.out.println("Last line of the code");
       

    }

    }

